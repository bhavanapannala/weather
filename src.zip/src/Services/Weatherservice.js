import axios from 'axios';
export default class Weatherservice{
    static baseUrl = 'http://localhost:3001/'
    static addlocation( add, name ) {
        // the backend expects productId to be present in the data being sent to it
        add.locationname = parseInt( name );

        return axios.post( 
            `${this.baseUrl}/addlocation`,
            add,
            { 
                headers: {  // HTTP Header is added
                    'Content-Type': 'application/json'
                }
            }
        )
            .then(function( response ) {
                return response.data;
            })
            .catch(function( error ) {
                console.log( error.message );
                throw error;
            });
    }
}