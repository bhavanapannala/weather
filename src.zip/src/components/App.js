import React, { Component } from 'react';
import {Route} from 'react-router-dom';
import Navbar from './Navbar';
import Home from './Home';
import Settings from './Settings';
class App extends Component {
    render() {
        return (
            
    <div>
        <Navbar/>
            <div className="container my-4">
                <Route path="/" exact component={Home}/>
                <Route path="/settings" exact component={Settings}/>
            </div>
            </div>
        );
    }
}

export default App;