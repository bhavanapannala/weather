import React, { Component } from 'react';
import Weatherservice from '../Services/Weatherservice';


class Settings extends Component {
    constructor(props) {
        super(props);
        this.state={
            addlocation:null
            }

        }
        addlocation= ev =>{
            ev.preventDefault();
            const add = this.state;

        Weatherservice.addlocation( add, name )
            .then(function( updatedlocation) {
                alert( `location is added` );
                // this.props.history.push( '' )
            })
            .catch(function() {
                alert( 'unable to add' );
            });
            
      }
    

    componentDidMount() {
        this.documentData = JSON.parse(localStorage.getItem('document'));
   
      if (localStorage.getItem('document')) {
          this.setState({
              addlocation: this.documentData.addlocation
      })
  } 
  else {
      this.setState({
          addlocation: ''
            })
         }
}

    
    render() {
        return (
        
                <div>
            <h2>Settings</h2>
            <div className="jumbotron">
            <form className='form-horizontal'>
            
            <div style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                        }}class="form-group">
                        <label for="savedlocations">Saved Locations:</label>
                        <select name="savedlocations" id="savedlocations"  placeholder="" >
                            <option></option>
                            <option>Bangalore</option>
                            <option>Chennai</option>
                            <option>Mysore</option>
                            <option>New Delhi</option>
                            <option>Hyderabad</option>
                        </select>{'                      '}
                        <button >Delete</button>
                        </div>
                        <div style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                        }}class="form-group">
                        <label for="addlocation">Add a new Location:</label>
                        <input  className="addlocation" placeholder="" type="text" name="addlocation"/>{'                         '}
                        <button type="submit" onSubmit={this.addlocation}>Add</button>
                        </div>
                        <div style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                        }}class="form-group">
                        <label for="setlocation">Set Default Location</label>{'                         '}
                        <select name="setlocation" id="setlocation"  placeholder="" >
                            <option></option>
                            <option>Bangalore</option>
                            <option>Chennai</option>
                            <option>Mysore</option>
                            <option>New Delhi</option>
                            <option>Hyderabad</option>
                        </select>{'                      '}
                        <button >Set</button>
                        </div>
                        <div style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center"
                        }}class="form-group-inline">
                        
                            
                        <label for="units">Change Units</label>
                       
                        <label ><input type="radio" name="optradio" checked/>Imperial</label><br/>
                        <label>< input type="radio" name="optradio"/>Metric</label>
                        
                        </div>
                        </form>
        </div>
        </div>
    );
    }
}



export default Settings;