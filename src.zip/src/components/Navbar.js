import React from 'react';
import { Link } from 'react-router-dom';

function Navbar(props) {
    return (
        <div>
            <div>
                <nav className="navbar navbar-expand navbar-dark bg-dark">
                    <ul className="nav navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to="/">Home </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/settings">Settings</Link>
                        </li>
                    </ul>
                </nav>
           
            </div>
           
        </div>
    );
}

export default Navbar;