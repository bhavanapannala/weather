import React from 'react';

function Home(props) {
    return (
        <div>
           <h4> Welcome To Weather Report</h4>
           <div style={{
                        display: "flex",
                        justifyContent: "right",
                        alignItems: "right"
                        }}class="form-group">
                        <label for="starRating">change Locations</label>
                        <select name="starRating" id="starRating"  placeholder="" >
                            <option></option>
                            <option>Bangalore</option>
                            <option>Chennai</option>
                            <option>Mysore</option>
                            <option>New Delhi</option>
                            <option>Hyderabad</option>
                        </select>
                        </div>
        </div>
    );
}

export default Home;